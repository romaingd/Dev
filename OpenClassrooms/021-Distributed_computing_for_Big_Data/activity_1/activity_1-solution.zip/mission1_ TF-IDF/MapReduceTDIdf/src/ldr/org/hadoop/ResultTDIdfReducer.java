package ldr.org.hadoop;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import ldr.org.hadoop.writables.CountersPair;
import ldr.org.hadoop.writables.DocTdItf;
import ldr.org.hadoop.writables.DocWithCountersPair;
import ldr.org.hadoop.writables.WordDoc;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ResultTDIdfReducer extends Reducer<Text, DocWithCountersPair, DocTdItf, NullWritable> {


    @Override
    public void reduce(final Text key, final Iterable<DocWithCountersPair> values,
            final Context context) throws IOException, InterruptedException {
    	
    	double numDocsPerWord = 0;
        Iterator<DocWithCountersPair> iterator = values.iterator();
        
        Map<WordDoc,CountersPair> maListe = new TreeMap<WordDoc, CountersPair>();
        
        while (iterator.hasNext()) {
        	DocWithCountersPair elt = iterator.next();
	       	 String word = key.toString();
             WordDoc wd= new WordDoc(elt.docName, word);
             CountersPair cp= new CountersPair(elt.wordsPerDoc,elt.wordCount );
        	maListe.put(wd, cp );
        	numDocsPerWord += 1;
        }
        Map<DocTdItf,NullWritable> maListeTriee = new TreeMap<DocTdItf, NullWritable>();
        for(WordDoc keyList : maListe.keySet()){
        	
        	CountersPair cp = maListe.get(keyList);
             double wordCountDbl = Double.parseDouble(Integer.toString(cp.wordCount));
             double wordsPerDocDbl = Double.parseDouble(Integer.toString(cp.wordsPerDoc));
	       	 double tdidf = ( wordCountDbl /wordsPerDocDbl);
	       	 
	       	 tdidf = tdidf  * Math.log(numDocsPerWord / 2);
	       	
	       	 DocTdItf dt = new DocTdItf(keyList.docName, tdidf, keyList.wordName);
	       	maListeTriee.put(dt, NullWritable.get());
        	
        }
        for(DocTdItf dt : maListeTriee.keySet()){
        	context.write(dt, NullWritable.get());
        }
    }
}