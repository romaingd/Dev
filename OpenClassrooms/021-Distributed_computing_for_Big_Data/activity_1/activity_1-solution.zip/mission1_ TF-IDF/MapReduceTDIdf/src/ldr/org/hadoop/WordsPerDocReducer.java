package ldr.org.hadoop;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import ldr.org.hadoop.writables.CountersPair;
import ldr.org.hadoop.writables.WordDoc;
import ldr.org.hadoop.writables.WordWordCount;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class WordsPerDocReducer extends Reducer<Text, WordWordCount, WordDoc, CountersPair> {


    @Override
    public void reduce(final Text docName, final Iterable<WordWordCount> values,
            final Context context) throws IOException, InterruptedException {
    	
    	int sum = 0;
        Iterator<WordWordCount> iterator = values.iterator();
        Map<WordDoc,Integer> maListe = new TreeMap<WordDoc, Integer>();
        while (iterator.hasNext()) {
        	WordWordCount pair = iterator.next();
        	
        	maListe.put(new WordDoc(pair.wordName,docName.toString()) , pair.wordCount);
            sum += pair.wordCount;
        }
        
        for(WordDoc keylist : maListe.keySet()){
        	
        	context.write(keylist, new CountersPair(maListe.get(keylist), sum));
        	
        }
       

    }
}