package ldr.org.hadoop.writables;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class CountersPair implements WritableComparable<CountersPair> {
	public int wordCount;
	public int wordsPerDoc;
	
	public CountersPair() {
	}
	public void set(int wordsPerDoc, int wordCount) {
		
		this.wordsPerDoc = wordsPerDoc;
		this.wordCount = wordCount;
	}

	public CountersPair(int wordsPerDoc, int wordCount) {
		super();
		this.wordsPerDoc = wordsPerDoc;
		this.wordCount = wordCount;
	}

	
	@Override
	public String toString() {
	return Integer.toString(this.wordsPerDoc) + "\t" + Integer.toString(this.wordCount);
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		wordsPerDoc = in.readInt();
		wordCount = in .readInt();
		
	}
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeInt(wordsPerDoc);
		out.writeInt(wordCount);
		
	}
	@Override
	public int compareTo(CountersPair o) {
		if (o==null) return 0;
		else {
			int wordsPerDocCmp=Integer.compare(wordsPerDoc, o.wordsPerDoc);
			if (wordsPerDocCmp==0) {
				return Integer.compare(wordCount, o.wordCount);
			}return wordsPerDocCmp;
		}
	}

}
