package ldr.org.hadoop.writables;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.text.DecimalFormat;

import org.apache.hadoop.io.WritableComparable;

public class DocTdItf implements WritableComparable<DocTdItf> {
	static final DecimalFormat DF = new DecimalFormat("###.########");
	public String docName;
	public double tdidf;
	public String wordName;
	
	public DocTdItf(String docName, double tdidf, String wordName) {
		super();
		this.docName = docName;
		this.tdidf = tdidf;
		this.wordName = wordName;
	}

	//on veut trier par td-idf inverse
	@Override
	public int compareTo(DocTdItf o) {
		
		int docNameCmp = docName.compareTo(o.docName);
		if (docNameCmp==0) {
			int tdidfCmp =  (-1) * Double.compare(tdidf, o.tdidf);
			if (tdidfCmp==0) return wordName.compareTo(o.wordName);
			else return tdidfCmp;
		}
		
		else return docNameCmp;
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.docName=in.readUTF();
		this.tdidf=in.readDouble();
		this.wordName = in.readUTF();

	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(docName);
		out.writeDouble(tdidf);
		out.writeUTF(wordName);

	}

	@Override
	public String toString() {
		
		return docName + "\t" + wordName + "\t" + DF.format(tdidf);
	}

}
