package ldr.org.hadoop;

import java.io.IOException;

import ldr.org.hadoop.writables.DocWithCountersPair;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;



public class ResultTDIdfMapper extends Mapper <LongWritable, Text, Text, DocWithCountersPair>{
	
	
    

    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
    	
    	 String[] line = value.toString().split("\t");
    	  String docName = line[0];
    	  String word = line[1];
    	  int wordCount = Integer.parseInt(line[2]);
    	  int wordsPerDoc= Integer.parseInt(line[3]);
    	  
    	context.write(new Text(word), new DocWithCountersPair(docName,  wordsPerDoc,wordCount) );
    }

    public void run(Context context) throws IOException, InterruptedException {
        setup(context);
        while (context.nextKeyValue()) {
            map(context.getCurrentKey(), context.getCurrentValue(), context);
        }
        cleanup(context);
    }
    
}
