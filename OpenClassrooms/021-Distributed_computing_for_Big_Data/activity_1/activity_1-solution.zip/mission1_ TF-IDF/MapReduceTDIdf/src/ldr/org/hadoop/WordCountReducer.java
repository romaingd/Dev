package ldr.org.hadoop;

import java.io.IOException;
import java.util.Iterator;

import ldr.org.hadoop.writables.WordDoc;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class WordCountReducer extends Reducer<WordDoc, IntWritable, WordDoc, IntWritable> {

    private IntWritable totalWordCount = new IntWritable();

    @Override
    public void reduce(final WordDoc key, final Iterable<IntWritable> values,
            final Context context) throws IOException, InterruptedException {

        int sum = 0;
        Iterator<IntWritable> iterator = values.iterator();

        while (iterator.hasNext()) {
            sum += iterator.next().get();
        }

        totalWordCount.set(sum);
        // context.write(key, new IntWritable(sum));
        context.write(key, totalWordCount);
    }
}