package ldr.org.hadoop.writables;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class DocWithCountersPair implements WritableComparable<DocWithCountersPair> {
	public String docName;
	public int wordCount;
	public int wordsPerDoc;
	
	public DocWithCountersPair() {
	}
	public void set(String docName,int wordsPerDoc, int wordCount) {
		this.docName = docName;
		this.wordsPerDoc = wordsPerDoc;
		this.wordCount = wordCount;
	}

	public DocWithCountersPair(String docName,int wordsPerDoc, int wordCount) {
		super();
		set( docName, wordsPerDoc,  wordCount);
		
	}

	
	@Override
	public String toString() {
	return docName + "\t" + Integer.toString(this.wordsPerDoc) + "\t" + Integer.toString(this.wordCount);
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		docName = in.readUTF();
		wordsPerDoc = in.readInt();
		wordCount = in .readInt();
		
	}
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(docName);
		out.writeInt(wordsPerDoc);
		out.writeInt(wordCount);
		
	}
	@Override
	public int compareTo(DocWithCountersPair o) {
		if (o==null) return 0;
		else {
			int docNameCmp = docName.compareTo(o.docName);
			if (docNameCmp==0){
				int wordsPerDocCmp=Integer.compare(wordsPerDoc, o.wordsPerDoc);
				if (wordsPerDocCmp==0) {
					return Integer.compare(wordCount, o.wordCount);
				} else return wordsPerDocCmp;
				
			}else return docNameCmp;
		}
	}

}
