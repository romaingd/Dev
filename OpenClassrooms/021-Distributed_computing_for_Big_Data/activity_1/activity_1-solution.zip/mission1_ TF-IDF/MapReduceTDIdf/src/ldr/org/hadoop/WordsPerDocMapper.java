package ldr.org.hadoop;

import java.io.IOException;

import ldr.org.hadoop.writables.WordWordCount;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;



public class WordsPerDocMapper extends Mapper <LongWritable, Text, Text, WordWordCount>{
	
	
    

    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
    	
    	 String[] line = value.toString().split("\t");
    	 String docName = line[1];
    	 String word = line[0];
    	 int wordCount = Integer.parseInt(line[2]); 
    	 context.write(new Text(docName), new WordWordCount(word, wordCount));
    }

    public void run(Context context) throws IOException, InterruptedException {
        setup(context);
        while (context.nextKeyValue()) {
            map(context.getCurrentKey(), context.getCurrentValue(), context);
        }
        cleanup(context);
    }

}
