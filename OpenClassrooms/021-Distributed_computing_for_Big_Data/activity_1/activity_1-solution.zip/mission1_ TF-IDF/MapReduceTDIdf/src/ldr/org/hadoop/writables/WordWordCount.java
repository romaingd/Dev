package ldr.org.hadoop.writables;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class WordWordCount implements WritableComparable<WordWordCount> {
	public String wordName;
	public int wordCount;
	
	public WordWordCount() {
	}
	public void set(String wordName, int wordCount) {
		
		this.wordName = wordName;
		this.wordCount = wordCount;
	}

	public WordWordCount(String wordName, int wordCount) {
		super();
		this.wordName = wordName;
		this.wordCount = wordCount;
	}

	
	@Override
	public String toString() {
	return this.wordName + "\t" + Integer.toString(this.wordCount);
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		wordName = in.readUTF();
		wordCount = in .readInt();
		
	}
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(wordName);
		out.writeInt(wordCount);
		
	}
	@Override
	public int compareTo(WordWordCount o) {
		if (o==null) return 0;
		else {
			int wordNameCmp= this.wordName.compareTo(o.wordName);
			if (wordNameCmp==0) {
				return Integer.compare(wordCount, o.wordCount);
			}return wordNameCmp;
		}
	}

}
