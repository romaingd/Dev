package ldr.org.hadoop;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

import ldr.org.hadoop.writables.WordDoc;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

public class WordCountMapper extends Mapper<LongWritable, Text, WordDoc, IntWritable> {
	private final static IntWritable one = new IntWritable(1);
    

    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
    	Set<String> stopWordsSet = new HashSet<String>();
    	String sCurrentLine;
    	FileSplit fileSplit = (FileSplit)context.getInputSplit();
    	String docName = fileSplit.getPath().getName();
    	FileReader fr=new FileReader("ref/stopwords_en.txt");
		@SuppressWarnings("resource")
		BufferedReader br= new BufferedReader(fr);
        while ((sCurrentLine = br.readLine()) != null){
        	stopWordsSet.add(sCurrentLine);
        }
	        
        String line = value.toString();
      
        
        StringTokenizer tokenizer = new StringTokenizer(line);
        while (tokenizer.hasMoreTokens()) {
        	String token =tokenizer.nextToken();
        	token = token.toLowerCase();
        	if (!stopWordsSet.contains(token) ){
        		token = token.replaceAll("[^a-z]", "");
        		if (token.length()> 3) {
            		
            		
            		context.write(new WordDoc(token,docName), one);
        			
        		}
        	}
        }
    }

    public void run(Context context) throws IOException, InterruptedException {
        setup(context);
        while (context.nextKeyValue()) {
            map(context.getCurrentKey(), context.getCurrentValue(), context);
        }
        cleanup(context);
    }

}
