package ldr.org.hadoop.writables;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class WordDoc implements WritableComparable<WordDoc> {
	public String wordName;
	public String docName;
	@Override
	public void readFields(DataInput in) throws IOException {
		this.wordName = in.readUTF();
		this.docName = in.readUTF();

	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(wordName);
		out.writeUTF(docName);

	}
	public WordDoc() {
	}
	public void set(String wordName, String docName) {
		
		this.wordName = wordName;
		this.docName = docName;
	}

	public WordDoc(String wordName, String docName) {
		super();
		this.wordName = wordName;
		this.docName = docName;
	}

	@Override
	public int compareTo(WordDoc o) {
		if (o==null) return 0;
		else {
			int docNameCmp = this.docName.compareTo(o.docName);
			if (docNameCmp==0) return this.wordName.compareTo(o.wordName);
			else return docNameCmp;
		}
	}
	@Override
	public String toString() {
	return this.wordName + "\t" + this.docName;
	}

}
