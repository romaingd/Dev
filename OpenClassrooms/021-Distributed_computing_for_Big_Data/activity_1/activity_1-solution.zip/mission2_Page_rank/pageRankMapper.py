#! /usr/bin/env python3

import sys

#lecture du fichier d'entrée pour alimenter le reducer
for line in sys.stdin:
    i, type, j, val = line.split()
    i =int(i)
    j=int(j)
    val = float(val)
    print("%d\t%s\t%d\t%f" % (i, type, j, val))

    
