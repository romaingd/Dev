#! /usr/bin/env python3
import sys
s = 0.25
n = 7966
for line in sys.stdin:
    # Supprimer les espaces
    line = line.strip()
    # recupérer les mots
    i, listPids  = line.split(":")
    i = int(i)
    pids = listPids.split()
    
    
    # operation map,
    #ecriture de P = (1-s)×T + s/n
    for link in pids:
        j=int(link)
        # suppression des valeurs '-1' correspondant à la fin de ligne
        if (j > -1 and len(pids)-1 > 0):
            print("%d\t%s\t%d\t%f" % (i, "P", j, (1-s) * (1 / (len(pids)-1)) + s/n))

#écriture du vecteur X_0 de taille n dont chaque élément vaut 1/n
for j in range(0, n+1):
    print("%d\t%s\t%d\t%f" % (j, "V", j, 1/n))
    
            
