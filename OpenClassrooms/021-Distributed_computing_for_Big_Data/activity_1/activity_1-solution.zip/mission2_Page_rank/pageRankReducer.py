#! /usr/bin/env python3

import sys

A = {}
x ={}
v={}
#lecture de la matrice et du vecteur
for line in sys.stdin:
    line = line.strip()
    
    i, type, j, val = line.split()
    i =int(i)
    j=int(j)
    val = float(val)
    if(type=="V"):
        v[i] = val
    else :
        A[(i,j)]=(val)
     
for (i,j),val in A.items():
    #réécriture de la matrice pour un prochain tour
    print("%d\t%s\t%d\t%f" % (i, "P", j, val))
    #multilication de la matrice avec le vecteur
    for k,vk in v.items():
        if(k not in x):
            x[k] = 0
        if(j==k) :
            x[k]+=val * vk
# écriture du nouveau vecteur X_..            
for j,val in x.items():
    if (val > 0):
        print("%d\t%s\t%d\t%f" % (j, "V", j, val))

